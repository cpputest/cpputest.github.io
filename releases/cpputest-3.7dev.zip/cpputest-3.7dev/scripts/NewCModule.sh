#!/bin/bash
TEMPLATE_DIR=${CPPUTEST_HOME}/scripts/templates
source ${CPPUTEST_HOME}/scripts/GenerateSrcFiles.sh ClassNameC c NoMock $1 $2

