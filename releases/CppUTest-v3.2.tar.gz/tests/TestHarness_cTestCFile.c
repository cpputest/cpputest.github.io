
#include "CppUTest/TestHarness_c.h"
#include "CppUTest/PlatformSpecificFunctions_c.h"

void functionWithUnusedParameter(void* PUNUSED(unlessParamater))
{

}
