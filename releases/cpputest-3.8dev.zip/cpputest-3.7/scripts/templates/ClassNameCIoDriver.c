#include "ClassName.h"
#include "IO.h"

void ClassName_Create(void)
{
}

void ClassName_Destroy(void)
{
}


