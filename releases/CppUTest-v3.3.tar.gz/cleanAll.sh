#Generated file - cleanAll.sh
echo "Running cleanAll for CppUTest v3.3 created on 2012-08-24-09-41"
export CPPUTEST_HOME=$(pwd)
echo "export CPPUTEST_HOME=$(pwd)/"
make cleanEverythingInstall
