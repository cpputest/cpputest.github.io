cpputest
========

CppUTest unit testing and mocking framework for C/C++