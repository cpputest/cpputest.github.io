#ifndef D_ClassName_H
#define D_ClassName_H

/**********************************************************************
 *
 * ClassName is responsible for ...
 *
 **********************************************************************/

typedef struct ClassNameStruct * ClassName;

ClassName ClassName_Create(void);
void ClassName_Destroy(ClassName);

#endif  /* D_FakeClassName_H */
