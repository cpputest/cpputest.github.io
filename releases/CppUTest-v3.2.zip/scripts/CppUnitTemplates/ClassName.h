#ifndef D_ClassName_H
#define D_ClassName_H

///////////////////////////////////////////////////////////////////////////////
//
//  ClassName is responsible for ...
//
///////////////////////////////////////////////////////////////////////////////

class ClassName
  {
  public:
    explicit ClassName();
    virtual ~ClassName();

  private:

    ClassName(const ClassName&);
    ClassName& operator=(const ClassName&);

  };

#endif  // D_ClassName_H
