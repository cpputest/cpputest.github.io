#Generated file - cleanAll.sh
echo "Running cleanAll for CppUTest v3.2 created on 2012-08-08-11-35"
export CPPUTEST_HOME=$(pwd)
echo "export CPPUTEST_HOME=$(pwd)/"
make cleanEverythingInstall
