#ifndef D_FakeClassName_H
#define D_FakeClassName_H

/**********************************************************
 *
 * FakeClassName is responsible for providing a
 * test stub for ClassName
 *
 **********************************************************/

#include "ClassName.h"

#endif  /* D_FakeClassName_H */
