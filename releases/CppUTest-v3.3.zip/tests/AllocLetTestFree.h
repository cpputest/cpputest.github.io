#ifndef D_AllocLetTestFree_H
#define D_AllocLetTestFree_H

typedef struct AllocLetTestFreeStruct * AllocLetTestFree;

AllocLetTestFree AllocLetTestFree_Create(void);
void AllocLetTestFree_Destroy(AllocLetTestFree);

#endif  /* D_FakeAllocLetTestFree_H */
